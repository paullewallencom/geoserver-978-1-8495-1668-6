
//Base variables for chapter 6
var GEOSERVERBASE = "http://localhost:8080"; //no slash
// Layers loaded in chapter 5 and 6
var CountyLayer = "tiger:tl_2011_us_county";
