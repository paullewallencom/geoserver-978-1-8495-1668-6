var GEOSERVERBASE = "http://localhost:8080";
var CountyLayer = 'tiger:tl_2011_us_county';
var CountriesLayer = 'NaturalEarth:ne_50m_admin_0_countries';
var RiversLayer = 'NaturalEarth:50m-rivers-lake-centerlines';
