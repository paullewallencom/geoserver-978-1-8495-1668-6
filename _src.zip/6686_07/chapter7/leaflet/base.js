var GEOSERVERBASE = "http://localhost:8080";
var CountyLayer = "tiger:tl_2011_us_county";
